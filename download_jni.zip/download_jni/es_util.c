#include "es_util.h"
/*
 * es_util.c
 *
 *  Created on: Dec 8, 2011
 *      Author: mhoque
 */

char *time_stamp()
{

	char *timestamp = (char *)malloc(sizeof(char) * 16);
	time_t ltime;
	ltime=time(NULL);
	struct tm *tm;
	tm=localtime(&ltime);

	sprintf(timestamp,"%04d-%02d-%02d-%02d-%02d-%02d", tm->tm_year+1900, tm->tm_mon,
		tm->tm_mday, tm->tm_hour, tm->tm_min, tm->tm_sec);
	return timestamp;
}


int get_radio_server_socket(char* client_payload,int read_bytes)
{


	int proxy_server=-1;

	char request[110],hostname[100],port[10],new_req[100];
	int flag_h=1, flag_p=0,flag_r=0;

	int server_port,begin=0,index=0;


	/* read the socket integer*/

	if (read_bytes>0)
	{
		memset(request,'\0',110);
		memset(hostname,'\0',100);
		memset(port,'\0',10);
		memset(new_req,'\0',100);
		printf("Radio request.........................\n%s",client_payload);

		if((char*)strstr(client_payload,"myradio_")!=NULL)
		{
			begin=read_bytes-strlen((char*)strstr(client_payload,"myradio_"))+strlen("myradio_");
			while(client_payload[begin]!=' ')
			{
				if(client_payload[begin]=='_')
					request[index]='.';
				else if (client_payload[begin]=='A')
					request[index]=':';
				else if (client_payload[begin]=='B')
					request[index]='/';
				else
					request[index]=client_payload[begin];

				++index;
				++begin;
			}

			index=0,begin=0;
			while(request[begin]!='\0')
			{

				if(request[begin]==':')
				{
					flag_p=1;
					flag_h=0;
					index=0;
					begin=begin+1;
				}
				if(request[begin]=='/')
				{
					flag_r=1;
					flag_h=0;
					flag_p=0;
					index=0;
					begin=begin+1;
				}


				if(flag_h)
				{
					hostname[index]=request[begin];
					++index;
				}
				if(flag_p)
				{
					port[index]=request[begin];
					++index;
				}
				if(flag_r)
				{
					new_req[index]=request[begin];
					++index;
				}




				++begin;
			}
			if(hostname[strlen(hostname)]==':') hostname[strlen(hostname)]='\0';
			if(port[strlen(port)]=='/') port[strlen(port)]='\0';
			server_port = atoi(port);

			if(server_port==0)
				server_port = 80;

		}// Parsing is done; more parsing can be added here like other audio/video
		else
		{
			//close(client_proxy);
			return -1;
		}

		/* Now we have server address and port; we need to connect to the server and
		 *	forward the client initial request */
		{

			struct sockaddr_in serveraddr;
			struct hostent *server;



			server=gethostbyname(hostname);
			if (server == NULL)
			{
				printf( "%s Error %s; no such host %s is found \n", __FUNCTION__,strerror(errno),hostname);
				//close(client_proxy);
				return -1;
			}

			bzero((char *) &serveraddr, sizeof(serveraddr));
			serveraddr.sin_family = AF_INET;
			bcopy((char *)server->h_addr,(char *)&serveraddr.sin_addr.s_addr, server->h_length);
			serveraddr.sin_port = htons(server_port);

			proxy_server= socket(AF_INET, SOCK_STREAM, 0);
			int new_con=connect(proxy_server,(const struct sockaddr*)&serveraddr, sizeof(serveraddr));
			if (new_con<0)
			{
				printf( "%s: Error %s; connecting to the radio server %s \n",__FUNCTION__, strerror(errno),hostname);
				//close(client_proxy);
				close(proxy_server);
				return proxy_server;
			}

			char new_request[BUF_SIZE];
			memset(new_request,'\0',BUF_SIZE);
			strcpy(new_request,"GET /");
                        strcat(new_request,new_req);
                        strcat(new_request," HTTP/1.0\r\n");
                        strcat(new_request,"Host: ");
                        strcat(new_request,hostname);
			strcat(new_request,":");
			strcat(new_request,port);
			strcat(new_request,"\r\n");

			index=0;
			begin=0;
			if((char*)strstr(client_payload,"Host:")!=NULL)
			{
				begin=strlen(client_payload)-strlen((char*)strstr(client_payload,"Host:"));
				while(client_payload[begin]!='\r')
					++begin;

				begin=begin+2;
			}

			char part_two[strlen(client_payload)-begin];
			memset(part_two,'\0',strlen(client_payload)-begin);
			strcpy(part_two,client_payload+begin);
			strcat(new_request,part_two);

			int bytes_write=write(proxy_server,new_request,strlen(new_request));
			if (bytes_write<0)
			{
				 close(proxy_server);
				 return -1;
			}

		}
		/* read from the proxy-client socket and write to proxy-server socket */
	}//end of if

	return proxy_server;
}

int get_3gpstream_rate(char* header,int  header_len)
{
	int val=0,begin=0,index=0;
	//double value=0;
	char content[12];
	memset(content,'\0',12);
	if(strstr(header,"Content-Length: ")!=NULL)
	{
		begin=header_len-strlen(strstr(header,"Content-Length: "))+strlen("Content-Length: ");
		//printf("Contentlength found:%d....%d\n",begin,header_len);

		while(header[begin]!='\r')
		{
			content[index]=header[begin];
			++index;
			++begin;
		}
		val=atoi(content);
		printf("Content length..%s..%d\n",content,val);

	}
	return val;
}


void convert_socket_blockint(int sock)
{
	int flags, f_flags;
	flags=fcntl(sock,F_GETFL,0);
	if(flags<0)
	{
		printf("%s Error %s \n",__FUNCTION__,strerror(errno));
		return;
	}

	flags&=~O_NONBLOCK;

	f_flags=fcntl(sock,F_SETFL,flags);
	if(f_flags<0)
	{

		printf("%s Error %s \n",__FUNCTION__,strerror(errno));
		return;
	}
}



void convert_socket_nonblock(int sock)
{
	int flags, f_flags;
	flags=fcntl(sock,F_GETFL,0);
	if(flags<0)
	{
		printf("%s Error %s \n",__FUNCTION__,strerror(errno));
		return;
	}

	flags|=O_NONBLOCK;

	f_flags=fcntl(sock,F_SETFL,flags);
	if(f_flags<0)
	{

		printf("%s Error %s \n",__FUNCTION__,strerror(errno));
		return;
	}
}

void get_host_port(char *payload,char *hostname, int *server_port)
{

	char host[110],hname[100],port[10];
	memset(host,'\0',150);
	memset(hname,'\0',100);
	memset(port,'\0',10);

	char *loc=strstr(payload,"Host:");
	int begin=strlen(payload)-strlen(loc)+strlen("Host:")+1;

	if(loc!=NULL)
	{

		int index=0;
		while(payload[begin]!='\r')
		{
			host[index]=payload[begin];
			++index;
			++begin;
		}

		index=0;
		int p=0,h=0,flag=0;

		while(host[index]!='\0')
		{
			if (host[index]==':')
			{
				++index;
				flag=1;
			}
			if (!flag)
			{
				hname[h]=host[index];
				++h;
			}

			else
			{
				port[p]=host[index];
				++p;
			}

			++index;
		}

		//getting the port
		*server_port = atoi(port);


		if(*server_port==0)
			*server_port = 80;

		// copying the hostname
		strcpy(hostname,hname);
	}
	return;
}


int open_squid_port()
{
    struct sockaddr_in rem_addr;
    int len, s, x;
    struct hostent *H;

    H = gethostbyname("localhost");
    if (!H)
	return (-2);

    len = sizeof(rem_addr);

    s = socket(AF_INET, SOCK_STREAM, 0);
    if (s < 0)
	return s;

    //setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &on, 4);
    //int window_size=256*1024;
    //setsockopt(s,SOL_SOCKET,SO_SNDBUF,&window_size,sizeof(window_size));
    //setsockopt(s,SOL_SOCKET,SO_RCVBUF,&window_size,sizeof(window_size));
    len = sizeof(rem_addr);
    memset(&rem_addr, '\0', len);
    rem_addr.sin_family = AF_INET;
    memcpy(&rem_addr.sin_addr, H->h_addr, H->h_length);
    rem_addr.sin_port = htons(SQUID_PORT);
    x = connect(s, (struct sockaddr *) &rem_addr, len);
    if (x < 0)
    {
    	//printf("%s Eroror \n",strerror(errno));
    	close(s);
    	return x;
    }

    return s;
}

int parse_check_flv_metadata(u_char *metadata,const char* element,int flv_length)
{
	int i=0, pos=-1,length=strlen(element);
	u_char temp[length];

	for(i=0;i<(flv_length-length);++i)
	{

		memset(temp,'\0',length);
		memcpy(temp,metadata+i,length);
		if(memcmp(temp,element,length)==0)
		{
			//printf("Metadtaa found..............%s and pos:%d...\n and meta %s\n",element,i,metadata);
			pos=i+length;
			break;
			//return pos;
		}
	}
	return pos;
}


double flv_int_double(uint64_t v)
{
     if(v+v > 0xFFEULL<<52)
         return 0.0/0.0;
     return ldexp(((v&((1LL<<52)-1)) + (1LL<<52)) * (v>>63|1), (v>>52&0x7FF)-1075);
 }




uint32_t parse_mp4_datarate(u_char *metadata,int flv_length)
{
	uint32_t val;

	int i=0;
	for(i=0;i<flv_length;++i)
	{
		char temp[5];
		memset(temp,'\0',5);
		memcpy(temp,metadata+i,4);
		if(memcmp(temp,"btrt",4)==0)
		{

			int pos=i+4;
			pos+=4;
			pos+=4;
			uint8_t value[4];
			memcpy(value,metadata+pos,4);
			val=(uint32_t)value[0]<<24;
			val|=(uint32_t)value[1]<<16;
			val|=(uint32_t)value[2]<<8;
			val|=(uint32_t)value[3];
			printf("Btrt found.....%d.....total:%d\n",i,val);
			break;
		}
	}
	return val;
}


uint64_t parse_flv_metadata(u_char *metadata, const char* element,int *ele_type,int flv_length)
{
		int pos=-1, ele_length=0;
		uint64_t val;

		uint8_t metadata_value[8];

		pos=parse_check_flv_metadata(metadata,element,flv_length);
		*ele_type=(int)metadata[pos];

		if(*ele_type==FLV_DATA_TYPE_NUMBER)
		{
			ele_length=8;
			memcpy(metadata_value,metadata+pos+1,ele_length);
			val=(uint64_t)metadata_value[0]<<56;
			val|=(uint64_t)metadata_value[1]<<48;
			val|=(uint64_t)metadata_value[2]<<40;
			val|=(uint64_t)metadata_value[3]<<32;
			val|=(uint64_t)metadata_value[4]<<24;
			val|=(uint64_t)metadata_value[5]<<16;
			val|=(uint64_t)metadata_value[6]<<8;
			val|=(uint64_t)metadata_value[7];


		}
		else if(*ele_type==FLV_DATA_TYPE_BOOL)
		{
			ele_length=1;
			val=(int)metadata[pos+1];
		}

		//printf("%s: exiting................\n",__FUNCTION__);
	return val;
}
/*

long int get_stream_rate(const char* file_name)
{
	long int stream_rate=0;

	avcodec_register_all();
	av_register_all();
	AVFormatContext *p_format_ctx;

	int video_stream=-1,i=0;
	usleep(1000);

	AVProbeData probe_data;
	probe_data.filename = file_name;
	probe_data.buf_size = 4096;
	probe_data.buf = (unsigned char *) malloc(probe_data.buf_size);
	AVInputFormat *ret = av_probe_input_format(&probe_data, 1);
	if(av_open_input_file(&p_format_ctx,file_name, ret, 4096,NULL)!=0)
	{
		printf("Could not open the file..%s\n",file_name);
		return -1;
	}

	dump_format(p_format_ctx, 0, file_name, 0);
	if(av_find_stream_info(p_format_ctx)<0)
	{
		printf("Could not find stream info..\n");
		//return -1;
	}

	for(i=0; i<p_format_ctx->nb_streams; i++)
	if(p_format_ctx->streams[i]->codec->codec_type==CODEC_TYPE_VIDEO)
	{
	  video_stream=i;
	  break;
	}

	stream_rate=p_format_ctx->bit_rate;
	printf("Found bit rate....%ld\n",stream_rate);
	av_close_input_file(p_format_ctx);
	return stream_rate;
}*/

long int get_total_datarate(u_char* metadata,int flv_length)
{

	long int total_data_rate=0;
	char metadata_elements[]="- duration - totalduration height width audiodatarate btrt videodatarate "
			"totaldatarate bytelength starttime framerate.";

	int element_type=0;
	double number_value=0.0;

	printf("Flv length.............%d\n",flv_length);
	char *token=strtok(metadata_elements," ,.-");
	while(token!=NULL)
	{
		number_value=parse_flv_metadata(metadata,token,&element_type,flv_length);

		/*
		if(!strcmp(token,"audiodatarate"))
		{
				meta->audio_rate=(long int)flv_int_double(number_value)*1024;
				printf("%s..........................:%ld\n",token,meta->audio_rate);
		}
		else if(!strcmp(token,"videodatarate"))
		{
			meta->video_rate=(long int)flv_int_double(number_value)*1024;
			printf("%s..........................:%ld\n",token,meta->video_rate);

		}
		else
		*/
		if(!strcmp(token,"totaldatarate"))
		{
			total_data_rate=(long int)flv_int_double(number_value)*1024;
			//printf("%s..........................:%ld\n",token,total_data_rate);

		}

		if(!strcmp(token,"btrt"))
		{
			total_data_rate=(long int)flv_int_double(number_value)*1024;
			//printf("%s..........................:%ld\n",token,total_data_rate);

		}

		token=strtok(NULL, " ,.-");
	}

	//printf("%s: exiting................\n",__FUNCTION__);


	//meta->start_time=(long long int)meta->dub_start_time;
	return (total_data_rate/8);
}

int get_server_socket(int client_proxy)
{
	int server_port=SQUID_PORT,proxy_server=-1;
	proxy_server=open_squid_port(server_port);
	//convert_socket_nonblock(proxy_server);
	return proxy_server;
}

int mywrite(int fd, char *buf, int *len)
{
	int x = write(fd, buf, *len);
	if (x < 0)
		return x;
	if (x == 0)
		return x;
	if (x != *len)
		memmove(buf, buf+x, (*len)-x);
	*len -= x;
	return x;
}

void close_all(int client_sock,int server_sock)
{
	 close(client_sock);
	 close(server_sock);
}

int parse_server_payload(char* server_payload, int *content_length)
{
	int stream_req=0;

	if(strstr(server_payload,"Content-Type: video")!=NULL)
	{
			stream_req=1;
	}

	if(strstr(server_payload,"content-type:video")!=NULL)
	{
		stream_req=1;
	}


	if(strstr(server_payload,"Content-Type: Video")!=NULL)
	{
		stream_req=1;
	}

	return stream_req;
}

long int get_micro_seconds()
{

	struct timeval tv;
	long int total;

	gettimeofday(&tv, NULL);
	total = tv.tv_sec*1000000+tv.tv_usec;
	return total;
}


long int get_time_dif(long int old_time)
{
	struct timeval tv;
	long int dif,total;

	gettimeofday(&tv, NULL);
	total = tv.tv_sec*1000000+tv.tv_usec;
	dif=total-old_time;
	return dif;

}

void convert_socket_block(int sock)
{
	int flags, f_flags;
	flags=fcntl(sock,F_GETFL,0);
	if(flags<0)
	{
		printf("%s Error %s \n",__FUNCTION__,strerror(errno));

	}

	flags&=~O_NONBLOCK;

	f_flags=fcntl(sock,F_SETFL,flags);
	if(f_flags<0)
	{
		printf("%s Error %s \n",__FUNCTION__,strerror(errno));

	}



}

