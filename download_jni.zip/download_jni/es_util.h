#include "interface.h"

/*
 * es_util.h
 *
 *  Created on: Dec 8, 2011
 *      Author: mhoque
 */

#ifndef ES_UTIL_H_
#define ES_UTIL_H_

void convert_socket_block(int sock);
long int get_time_dif(long int old_time);
long int get_micro_seconds();
int parse_server_payload(char* server_payload, int *content_length);
void close_all(int client_sock,int server_sock);
int mywrite(int fd, char *buf, int *len);
int get_server_socket(int client_proxy);
long int get_total_datarate(u_char* metadata,int flv_length);
uint64_t parse_flv_metadata(u_char *metadata, const char* element,int *ele_type,int flv_length);
uint32_t parse_mp4_datarate(u_char *metadata,int flv_length);
double flv_int_double(uint64_t v);
int parse_check_flv_metadata(u_char *metadata,const char* element,int flv_length);
int open_squid_port();
void get_host_port(char *payload,char *hostname, int *server_port);
void convert_socket_nonblock(int sock);
void convert_socket_blockint(int sock);
int get_3gpstream_rate(char* header,int  header_len);
int get_radio_server_socket(char* client_payload,int read_bytes);
char *time_stamp();



#endif /* ES_UTIL_H_ */
