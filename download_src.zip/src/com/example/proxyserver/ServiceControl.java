package com.example.proxyserver;


import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;


public class ServiceControl extends Service{

	private String TAG = "MyStreamingProxy";

	@Override
	public IBinder onBind(Intent intent) 
	{
		// TODO Auto-generated method stub
		return null;

	}
	@Override
	public void onCreate() 
	{
		Toast.makeText(this, "My Service Created", Toast.LENGTH_LONG).show();
		Log.d(TAG, "onCreate");
		//cellSig.startSignalLevelListener();
	    //cellSig.displayTelephonyInfo();    
		
	}

	
	@Override
	public void onDestroy() 
	{
		Toast.makeText(this, "My Service Stopped", Toast.LENGTH_LONG).show();
		Log.d(TAG, "onDestroy");
        super.onDestroy();
        this.stopSelf();
    }

	@Override
	
	
	public void onStart(Intent intent, int startid) 
	{
		
		Toast.makeText(this, "My Service Started", Toast.LENGTH_LONG).show();
	
		/* Initialize mutex........*/
		Log.i(TAG,"Initializing Thread Mutex");
		JaniFunctions.initializemutex();
				
		/* Video Downloading Thread*/
		(new Thread(new Runnable(){public void run() 
	    {downloadThread();}})).start();
		  
		/* Video Playback Thread */
		(new Thread(new Runnable(){public void run() 
		{try {
			playbackThread();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}}})).start();

	}
	
	
	/* Video Downloading */
	public void downloadThread()
	{
		Log.i(TAG,"Downloading Thread Started.");
    	String requestUrl="http://www.youtube.com/watch?v=lZ0YO4ZXNRI";
    	int videoQuality=18;
    	
    	GetVideoUrlServer videoUrlObject=new GetVideoUrlServer(requestUrl,videoQuality);
    	//String videoId=videoUrlObject.getVideoId();
    	
    	downloadVideo(videoUrlObject);
	}

	private void applyAggressivePolicy()
	{
		
	}
	
	private void applyDefaultPolicy()
	{
		
		
	}
	
	
	
	private void downloadVideo(GetVideoUrlServer videoUrlObject)
	{
		boolean downloadInComplete=true;
		int con=0;
		long byterange=0,contentlength=0;
		String videoId=videoUrlObject.getVideoId();
		int videoQuality=videoUrlObject.getVideoQuality();
		int gotvideoUrls=videoUrlObject.receiveAndSetVideoUrl();
		int bitrate=0;
		
		
		
		
		/*Get the number of new threads to be generated*/
		int defBurst=40;
		int duration=videoUrlObject.getVideoDuration(videoId);
    	/*
		int lastBurst=0;
    	int numBurst=duration/defBurst;
    	
    	if(duration%defBurst!=0)
    	{
    		lastBurst=duration%defBurst;
    		if(lastBurst<10)
    			lastBurst=40+lastBurst;
    		else
    			numBurst=numBurst+1;
    	
    	}
    	
    	Log.i(TAG,""+numBurst+" "+lastBurst);
    	*/
    	
    	
		String videoRequest=videoUrlObject.getIndividualVideoUrlHttpRequest
				(videoQuality,byterange,contentlength);

		if((gotvideoUrls==200)&&(videoRequest.contains("videoplayback"))) 
		{
			String params="";
			while(downloadInComplete)
			{
	
		    	params=
		    	 "Host: "+videoRequest.split("\r\n")[1].split("Host: ")[1]+"\r\n"
		    	+"File-Name: "+videoUrlObject.getVideofileName(videoId,videoQuality)+"\r\n"
		    	+"Bit-Rate: "+bitrate+"\r\n"
		    	+"Burst-Duration: "+defBurst+"\r\n"
		    	+"Video-Duration: "+duration+"\r\n";
		    	//Log.i(TAG,params);
				String headerEle=JaniFunctions.getvideo(videoRequest,params);
				if((headerEle.contains("HTTP/1.1 200 OK"))||(headerEle.contains("HTTP/1.1 206 Partial Content")))
				{
					
					if(con==0)
					{
						contentlength=Integer.parseInt(StringUtils.getRangeOfBytes(headerEle, "Content-Length: ", '\r'));
						byterange=Integer.parseInt(StringUtils.getRangeOfBytes(headerEle, "Downloaded-Bytes: ", '\r'));
						bitrate=Integer.parseInt(StringUtils.getRangeOfBytes(headerEle, "Bit-Rate: ", '\r'));
						videoRequest=videoUrlObject.getIndividualVideoUrlHttpRequest
						(videoQuality,byterange,contentlength);
	
					}
					else
					{
						byterange=Integer.parseInt(StringUtils.getRangeOfBytes(headerEle, "Downloaded-Bytes: ", '\r'));
						if(byterange>=contentlength)
						{
							downloadInComplete=false;
							break;
						}
						else
							videoRequest=videoUrlObject.getIndividualVideoUrlHttpRequest
							(videoQuality,byterange,contentlength);
											
					}
					
					con=con+1;
				}
				else if (headerEle.contains("HTTP/1.1 302 Found"))
				{
					videoUrlObject.updateIndivudualUrl(headerEle.split("Location: ")[1].split("\r\n")[0],videoQuality);
					videoRequest=videoUrlObject.getIndividualVideoUrlHttpRequest(videoQuality,byterange,contentlength);
					Log.i(TAG,"Video is redirected "+"\n"+videoRequest);
				}
				else
				{
					Log.i(TAG,"Other Response."+"\n"+headerEle);
				}
			
			}//end of while
		}
		else
		{
			Log.i(TAG,"Could not find the video Url of "+videoQuality+" "+gotvideoUrls+videoRequest);
		}
		
	}//end of Function.

	public void playbackThread() throws InterruptedException
	{
		Log.i(TAG,"Playback Thread Started.");
		while(true)
		{
			
			Thread.sleep(3);
			//JaniFunctions.getmutexlock();
			
		}
	}
	
}
