package com.example.policy;

public class WifiSignal {

}
